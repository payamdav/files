import numpy as np
import pandas as pd
import numba as nb
import collections
import time
import plotly
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import itertools


Enum = collections.namedtuple('Enum', [
    'open',
    'high',
    'low',
    'close',

    'false',
    'true',

    'long',
    'short',
    'both',

    'id',
    'status',
    'direction',
    'size',
    'quote',
    'entry',
    'exit',
    'bprice',
    'sprice',
    'tp',
    'sl',
    'bfee',
    'sfee',
    'profit',
    'slot',

    'unused',
    'inposition',
    'exited',
    'exit_tp',
    'exit_sl',
    'exit_interval',
    'exit_signal',
    'exit_open',

    'cash',
    'min_cash',
    'max_cash',
    'order_count'

    ])

enum = Enum(0, 1, 2, 3, 0, 1, 1, 2, 3, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 1, 2, 3, 4, 5, 6, 7, 8, 0, 1, 2,3)


@nb.jit(nopython=True)
def nb_trader(ncandles, nentries, nexits, tp, sl, fee, max_interval, direction, norders, nprice, quote_amount, exit_order_on_interval, exit_on_same_candle, params, slot_params, slots, period, cols, max_orders, max_open_orders):
    # rows_number = ncandles.shape[0]
    rows_number = slots * period
    order_ids = []
    open_orders = []
    for c in range(cols):
        open_orders.append(0)

    cash = params[:, enum.cash]
    min_cash = params[:, enum.min_cash]
    max_cash = params[:, enum.max_cash]
    order_count = params[:, enum.order_count]

    slot_cash = slot_params[:, :, enum.cash]
    slot_min_cash = slot_params[:, :,enum.min_cash]
    slot_max_cash = slot_params[:, :,enum.max_cash]
    slot_order_count = slot_params[:, :,enum.order_count]

    progress = -1
    for i in range(0, rows_number):
        progress_now = (i * 100) // rows_number
        if progress_now != progress:
            progress = progress_now
            # print(f"\r", progress, "%")
        
        for c in range(cols):
            slot = int(i // period)
            if nentries[i, c] == 1 and open_orders[c] < max_open_orders and order_count[c] < max_orders:
                buy_price = nprice[i]
                norders[int(order_count[c]), c, enum.id] = int(order_count[c])
                norders[int(order_count[c]), c, enum.status] = enum.inposition
                norders[int(order_count[c]), c, enum.direction] = direction[c]
                norders[int(order_count[c]), c, enum.size] = quote_amount / buy_price
                norders[int(order_count[c]), c, enum.quote] = quote_amount
                norders[int(order_count[c]), c, enum.entry] = i
                norders[int(order_count[c]), c, enum.exit] = 0
                norders[int(order_count[c]), c, enum.bprice] = buy_price
                norders[int(order_count[c]), c, enum.sprice] = 0.0
                if norders[int(order_count[c]), c, enum.direction] == enum.long:
                    norders[int(order_count[c]), c, enum.tp] = buy_price * (1.0 + tp[c]) if tp[c] > 0 else 0
                    norders[int(order_count[c]), c, enum.sl] = buy_price * (1.0 - sl[c]) if sl[c] > 0 else 0
                else:
                    norders[int(order_count[c]), c, enum.tp] = buy_price * (1.0 - tp[c]) if tp[c] > 0 else 0
                    norders[int(order_count[c]), c, enum.sl] = buy_price * (1.0 + sl[c]) if sl[c] > 0 else 0
                norders[int(order_count[c]), c, enum.bfee] = quote_amount * fee
                norders[int(order_count[c]), c, enum.sfee] = 0.0
                norders[int(order_count[c]), c, enum.profit] = 0.0
                norders[int(order_count[c]), c, enum.slot] = slot

                order_ids.append((int(order_count[c]), c))
                order_count[c] += 1
                slot_order_count[c, slot] += 1
                open_orders[c] += 1

                cash[c] -= quote_amount
                if cash[c] < min_cash[c]:
                    min_cash[c] = cash[c]
                if cash[c] > max_cash[c]:
                    max_cash[c] = cash[c]

                slot_cash[c, slot] -= quote_amount
                if slot_cash[c, slot] < slot_min_cash[c, slot]:
                    slot_min_cash[c, slot] = slot_cash[c, slot]
                if slot_cash[c, slot] > slot_max_cash[c, slot]:
                    slot_max_cash[c, slot] = slot_cash[c, slot]
        for j, c in order_ids.copy():

            if norders[j, c, enum.status] == enum.inposition and (exit_on_same_candle == enum.true or norders[j, c, enum.entry] < i):
                sell_price = 0
                if exit_order_on_interval == 1 and (i - norders[j, c, enum.entry] > max_interval > 0):
                    # sell_price = ncandles[i, enum.open]
                    sell_price = nprice[i]
                    norders[j, c, enum.status] = enum.exit_interval
                elif norders[j, c, enum.sl] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.open] <= norders[j, c, enum.sl]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.open] >= norders[j, c, enum.sl])):
                    sell_price = norders[j, c, enum.sl]
                    norders[j, c, enum.status] = enum.exit_sl
                elif norders[j, c, enum.tp] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.open] >= norders[j, c, enum.tp]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.open] <= norders[j, c, enum.tp])):
                    sell_price = norders[j, c, enum.tp]
                    norders[j, c, enum.status] = enum.exit_tp
                elif norders[j, c, enum.sl] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.low] <= norders[j, c, enum.sl]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.high] >= norders[j, c, enum.sl])):
                    sell_price = norders[j, c, enum.sl]
                    norders[j, c, enum.status] = enum.exit_sl
                elif norders[j, c, enum.tp] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.high] >= norders[j, c, enum.tp]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.low] <= norders[j, c, enum.tp])):
                    sell_price = norders[j, c, enum.tp]
                    norders[j, c, enum.status] = enum.exit_tp
                elif nexits[i, c] == 1:
                    # sell_price = ncandles[i, enum.open]
                    sell_price = nprice[i]
                    norders[j, c, enum.status] = enum.exit_signal
                
                if sell_price > 0:
                    sell_quote = sell_price * norders[j, c, enum.size]
                    norders[j, c, enum.exit] = i
                    norders[j, c, enum.sprice] = sell_price
                    norders[j, c, enum.sfee] = sell_quote * fee
                    norders[j, c, enum.profit] = (sell_quote - norders[j, c, enum.quote] - norders[j, c, enum.bfee] - norders[j, c, enum.sfee]) if norders[j, c, enum.direction] == enum.long else (norders[j, c, enum.quote] - sell_quote - norders[j, c, enum.bfee] - norders[j, c, enum.sfee])

                    order_ids.remove((norders[j, c, enum.id], c))
                    open_orders[c] -= 1

                    cash[c] += (norders[j, c, enum.quote] + norders[j, c, enum.profit])
                    if cash[c] < min_cash[c]:
                        min_cash[c] = cash[c]
                    if cash[c] > max_cash[c]:
                        max_cash[c] = cash[c]

                    slot = int(norders[j, c, enum.entry] // period)
                    slot_cash[c, slot] += (norders[j, c, enum.quote] + norders[j, c, enum.profit])
                    if slot_cash[c, slot] < slot_min_cash[c, slot]:
                        slot_min_cash[c, slot] = slot_cash[c, slot]
                    if slot_cash[c, slot] > slot_max_cash[c, slot]:
                        slot_max_cash[c, slot] = slot_cash[c, slot]
    
    sell_price = ncandles[-1, enum.close]
    for j, c in order_ids.copy():
        if norders[j, c, enum.status] == enum.inposition:
            norders[j, c, enum.status] = enum.exit_open
            sell_quote = sell_price * norders[j, c, enum.size]
            norders[j, c, enum.exit] = rows_number - 1
            norders[j, c, enum.sprice] = sell_price
            norders[j, c, enum.sfee] = sell_quote * fee
            norders[j, c, enum.profit] = (sell_quote - norders[j, c, enum.quote] - norders[j, c, enum.bfee] - norders[j, c, enum.sfee]) if norders[j, c, enum.direction] == enum.long else (norders[j, c, enum.quote] - sell_quote - norders[j, c, enum.bfee] - norders[j, c, enum.sfee])

            order_ids.remove((norders[j, c, enum.id], c))
            open_orders[c] -= 1

            cash[c] += (norders[j, c, enum.quote] + norders[j, c, enum.profit])
            if cash[c] < min_cash[c]:
                min_cash[c] = cash[c]
            if cash[c] > max_cash[c]:
                max_cash[c] = cash[c]

            slot = int(norders[j, c, enum.entry] // period)
            slot_cash[c, slot] += (norders[j, c, enum.quote] + norders[j, c, enum.profit])
            if slot_cash[c, slot] < slot_min_cash[c, slot]:
                slot_min_cash[c, slot] = slot_cash[c, slot]
            if slot_cash[c, slot] > slot_max_cash[c, slot]:
                slot_max_cash[c, slot] = slot_cash[c, slot]


class Trader:
    def __init__(self, candles=None, signal_entries=None, signal_exits=None, price=None, tp=0, sl=0, fee=0, max_interval=0, freq='H', slots=1, direction=1, quote_amount=10, exit_order_on_interval=0, exit_on_same_candle=0, max_orders=10000000, max_open_orders=10000000, expand_to_sl_tp=False) -> None:
        self.fee = fee
        self.max_interval = max_interval
        self.freq = freq
        self.quote_amount = quote_amount
        self.exit_order_on_interval = exit_order_on_interval
        self.exit_on_same_candle = exit_on_same_candle
        self.max_orders = max_orders
        self.max_open_orders = max_open_orders
        if isinstance(candles, pd.DataFrame):
            self.candles = candles
        else:
            print("Please Provide candles in Pandas Dataframe format")
        self.ncandles = self.candles[['Open', 'High', 'Low', 'Close']].to_numpy()
        if price is None:
            self.nprice = self.candles['Close'].to_numpy()
        elif isinstance(price, str) and price in candles.columns:
            self.nprice = self.candles[price].to_numpy()
        elif isinstance(price, pd.Series):
            self.nprice = price.to_numpy()
        else:
            self.nprice = self.candles['Close'].to_numpy()

        self.rows = self.candles.shape[0]
        self.columns = ['col0']

        self.slots = slots
        self.period = self.rows // slots

        self.nentries = None
        self.nexits = None
        if expand_to_sl_tp and len(np.array(signal_entries).shape) == 1:
            sltemp = np.array(sl).copy()
            if sltemp.shape == ():
                sltemp = np.expand_dims(sltemp, axis=0).copy()
            tptemp = np.array(tp).copy()
            if tptemp.shape == ():
                tptemp = np.expand_dims(tptemp, axis=0).copy()
            le = max(sltemp.shape[0], tptemp.shape[0])
            self.sl = np.resize(sltemp, le).copy()
            self.tp = np.resize(tptemp, le).copy()
            self.signal_fixer(np.repeat(np.expand_dims(signal_entries, axis=1), repeats=len(self.sl), axis=1), np.repeat(np.expand_dims(signal_exits, axis=1), repeats=len(self.sl), axis=1))
        else:
            self.signal_fixer(signal_entries, signal_exits)

            self.tp = np.array(tp)
            if self.tp.shape == ():
                self.tp = np.broadcast_to(self.tp, self.cols)
            else:
                self.tp.resize(self.cols)

            self.sl = np.array(sl)
            if self.sl.shape == ():
                self.sl = np.broadcast_to(self.sl, self.cols)
            else:
                self.sl.resize(self.cols)

        self.direction = np.array(direction)
        if self.direction.shape == ():
            self.direction = np.broadcast_to(self.direction, self.cols)
        else:
            self.direction.resize(self.cols)
        self.direction = np.clip(self.direction, 1, 2)

        self.norders = np.full((min(self.rows, self.max_orders), self.cols, 15), 0.)
        self.params = np.full((self.cols,10), 0.)
        self.slot_params = np.full((self.cols, self.slots, 10), 0.)
    
    @property
    def cols(self):
        return len(self.columns)
    
    def signal_fixer(self, e, x):
        sige = pd.DataFrame(e)
        self.columns = sige.columns
        if self.cols == 0:
            self.columns = ['col0']
        self.nentries = sige.to_numpy().copy()
        self.nentries.resize(self.rows, self.cols)
        
        self.nexits = pd.DataFrame(x).to_numpy().copy()
        self.nexits.resize(self.rows, self.cols)

    def reinit(self):
        self.norders = np.full((min(self.rows, self.max_orders), self.cols, 15), 0.)
        self.params = np.full((self.cols,10), 0.)
        self.slot_params = np.full((self.cols, self.slots, 10), 0.)
    
    def trade_runner(self):
        time_lap = time.time()
        self.reinit()
        nb_trader(self.ncandles, self.nentries, self.nexits, self.tp, self.sl, self.fee, self.max_interval, self.direction, self.norders, self.nprice, self.quote_amount, self.exit_order_on_interval, self.exit_on_same_candle, self.params, self.slot_params, self.slots, self.period, self.cols, self.max_orders, self.max_open_orders)
        # print(f"Time Lapse: {round(time.time()-time_lap, 1)} Seconds")
    
    def report_base(self, col, col_params, orders):
        profit = orders[:, enum.profit].sum() if col_params[enum.order_count] > 0 else 0
        ret = round(100*profit/abs(col_params[enum.min_cash]), 2) if col_params[enum.min_cash] < 0 and col_params[enum.order_count] > 0 else 0
        Report = collections.namedtuple('Report', ['time_steps', 'order_count', 'sl', 'tp', 'init_cash', 'final_cash', 'min_cash', 'max_cash', 'profit', 'return_p', 'fees', 'long_count', 'short_count',
        'avg_duration', 'min_duration', 'max_duration', 'avg_profit', 'min_profit', 'max_profit', 'positive_profit', 'negative_profit', 'win_trades', 'loss_trades', 'win_rate', 
        'exit_tp', 'exit_sl', 'exit_interval', 'exit_open', 'exit_signal'])
        rep = Report(
            time_steps=self.period,
            order_count=col_params[enum.order_count],
            sl=self.sl[col],
            tp=self.tp[col],
            init_cash=0,
            final_cash=col_params[enum.cash],
            min_cash=col_params[enum.min_cash],
            max_cash=col_params[enum.max_cash],
            profit=profit,
            return_p=ret,
            fees=orders[:, [enum.bfee, enum.sfee]].sum() if col_params[enum.order_count] > 0 else 0,
            long_count=orders[orders[:, enum.direction] == enum.long].shape[0],
            short_count=orders[orders[:, enum.direction] == enum.short].shape[0],
            avg_duration=round((orders[:, enum.exit] - orders[:, enum.entry]).mean(), 1) if col_params[enum.order_count] > 0 else 0,
            min_duration=(orders[:, enum.exit] - orders[:, enum.entry]).min() if col_params[enum.order_count] > 0 else 0,
            max_duration=(orders[:, enum.exit] - orders[:, enum.entry]).max() if col_params[enum.order_count] > 0 else 0,
            avg_profit=round(orders[:, enum.profit].mean(), 3) if col_params[enum.order_count] > 0 else 0,
            min_profit=round(orders[:, enum.profit].min(), 3) if col_params[enum.order_count] > 0 else 0,
            max_profit=round(orders[:, enum.profit].max(), 3) if col_params[enum.order_count] > 0 else 0,
            positive_profit=round(orders[orders[:, enum.profit] > 0, enum.profit].sum(), 3) if col_params[enum.order_count] > 0 else 0,
            negative_profit=round(orders[orders[:, enum.profit] < 0, enum.profit].sum(), 3) if col_params[enum.order_count] > 0 else 0,
            win_trades=orders[orders[:, enum.profit] >= 0].shape[0] if col_params[enum.order_count] > 0 else 0,
            loss_trades=orders[orders[:, enum.profit] < 0].shape[0] if col_params[enum.order_count] > 0 else 0,
            win_rate=round(100 * orders[orders[:, enum.profit] >= 0].shape[0] / orders.shape[0], 2) if orders.shape[0] > 0 else 0,
            exit_tp=orders[orders[:, enum.status] == enum.exit_tp].shape[0] if col_params[enum.order_count] > 0 else 0,
            exit_sl=orders[orders[:, enum.status] == enum.exit_sl].shape[0] if col_params[enum.order_count] > 0 else 0,
            exit_interval=orders[orders[:, enum.status] == enum.exit_interval].shape[0] if col_params[enum.order_count] > 0 else 0,
            exit_open=orders[orders[:, enum.status] == enum.exit_open].shape[0] if col_params[enum.order_count] > 0 else 0,
            exit_signal=orders[orders[:, enum.status] == enum.exit_signal].shape[0] if col_params[enum.order_count] > 0 else 0,

        )
        return rep

    def report(self, col=0):
        col_params = self.params[col, :]
        orders = self.norders[0:int(col_params[enum.order_count]), col]
        return self.report_base(col, col_params, orders)
    
    def report_all_df(self):
        return pd.DataFrame(data=[self.report(col) for col in range(0, self.cols)], index=self.columns).T
    
    def report_all_array(self):
        return [self.report(col) for col in range(0, self.cols)]

    def report_slot(self, col=0, slot=0):
        col_params = self.slot_params[col, slot, :]
        orders = self.norders[0:int(self.params[col, enum.order_count]), col]
        orders = orders[orders[:, enum.slot] == slot]
        return self.report_base(col, col_params, orders)

    def report_slots_array(self, col=0):
        return [self.report_slot(col, slot) for slot in range(0, self.slots)]

    def report_slots_df(self, col=0):
        return pd.DataFrame(data=[self.report_slot(col, slot) for slot in range(0, self.slots)], index=range(0, self.slots)).T

    def report_cols_slots(self):
        return [self.report_slots_array(col) for col in range(0, self.cols)]

    def plot(self, col=0):
        fig = make_subplots(rows=1, cols=1, shared_xaxes=True)
        fig.add_trace(
            go.Candlestick(
                x=self.candles.index,
                open=self.candles.Open,
                high=self.candles.High,
                low=self.candles.Low,
                close=self.candles.Close,
                name='Candles',
            ),
            row=1,
            col=1
        )

        col_params = self.params[col, :]
        orders = self.norders[0:int(col_params[enum.order_count]), col]
        entries_iloc = np.unique(orders[:, enum.entry]).astype('int')
        price_series = pd.Series(data=self.nprice, index=self.candles.index)
        entries = pd.Series(data=np.nan, index=self.candles.index)
        entries.iloc[entries_iloc] = price_series.iloc[entries_iloc]
        fig.add_trace(
            go.Scatter(
                x=entries.index,
                y=entries,
                mode='markers',
                name="Entries",
                marker_color="#0000ff",
                marker_size=10,
                marker_symbol='triangle-up'
            ),
            row=1,
            col=1
        )

        exits_iloc = np.unique(orders[:, enum.exit]).astype('int')
        exit_series = pd.Series(data=(self.candles.Open + self.candles.Close) / 2, index=self.candles.index)
        exits = pd.Series(data=np.nan, index=self.candles.index)
        exits.iloc[exits_iloc] = exit_series.iloc[exits_iloc]
        fig.add_trace(
            go.Scatter(
                x=exits.index,
                y=exits,
                mode='markers',
                name="Exits",
                marker_color="#ff00ff",
                marker_size=10,
                marker_symbol='triangle-down'
            ),
            row=1,
            col=1
        )

        fig.update_layout(
            title_text="Plot",
            showlegend=True,
            dragmode='pan',
            template='plotly_dark',
            xaxis_rangeslider_visible=False,
            autosize=True,
            # width=1000,
            height=700,
        )
        fig.update_xaxes(showspikes=True, spikesnap="cursor", spikemode="across+marker", spikethickness=0.5, spikedash='solid', rangeslider_visible=False)
        fig.update_yaxes(showspikes=True, spikesnap="cursor", spikemode="across+marker", spikethickness=0.5, spikedash='solid')
        fig.show(config=dict({'scrollZoom': True}))


    def plot2(self, col=0):
        fig = make_subplots(rows=3, cols=1, shared_xaxes=True)
        fig.add_trace(
            go.Candlestick(
                x=self.candles.index,
                open=self.candles.Open,
                high=self.candles.High,
                low=self.candles.Low,
                close=self.candles.Close,
                name='Candles',
            ),
            row=1,
            col=1
        )

        col_params = self.params[col, :]
        orders = self.norders[0:int(col_params[enum.order_count]), col]
        entries_iloc = np.unique(orders[:, enum.entry]).astype('int')
        price_series = pd.Series(data=self.nprice, index=self.candles.index)
        entries = pd.Series(data=np.nan, index=self.candles.index)
        entries.iloc[entries_iloc] = price_series.iloc[entries_iloc]
        fig.add_trace(
            go.Scatter(
                x=entries.index,
                y=entries,
                mode='markers',
                name="Entries",
                marker_color="#0000ff",
                marker_size=10,
                marker_symbol='triangle-up'
            ),
            row=1,
            col=1
        )

        exits_iloc = np.unique(orders[:, enum.exit]).astype('int')
        exit_series = pd.Series(data=(self.candles.Open + self.candles.Close) / 2, index=self.candles.index)
        exits = pd.Series(data=np.nan, index=self.candles.index)
        exits.iloc[exits_iloc] = exit_series.iloc[exits_iloc]
        fig.add_trace(
            go.Scatter(
                x=exits.index,
                y=exits,
                mode='markers',
                name="Exits",
                marker_color="#ff00ff",
                marker_size=10,
                marker_symbol='triangle-down'
            ),
            row=1,
            col=1
        )


        exits_iloc = orders[:, enum.exit].astype('int')
        exit_series = pd.Series(data=(self.candles.Open + self.candles.Close) / 2, index=self.candles.index)
        exits = pd.Series(data=np.nan, index=self.candles.index)
        exits.iloc[exits_iloc] = orders[:, enum.profit]

        exit_colors = pd.Series(data=np.nan, index=self.candles.index)
        exit_colors.iloc[exits_iloc] = np.where(orders[:, enum.profit] > 0, "#00ff00", "#ff0000")

        fig.add_trace(
            go.Scatter(
                x=exits.index,
                y=exits,
                mode='markers',
                name="Exits",
                marker_color=exit_colors,
                marker_size=10,
                marker_symbol='circle'
            ),
            row=2,
            col=1
        )

        fig.update_layout(
            title_text="Plot",
            showlegend=True,
            dragmode='pan',
            template='plotly_dark',
            xaxis_rangeslider_visible=False,
            autosize=True,
            # width=1000,
            height=700,
        )
        fig.update_xaxes(showspikes=True, spikesnap="cursor", spikemode="across+marker", spikethickness=0.5, spikedash='solid', rangeslider_visible=False)
        fig.update_yaxes(showspikes=True, spikesnap="cursor", spikemode="across+marker", spikethickness=0.5, spikedash='solid')
        fig.show(config=dict({'scrollZoom': True}))

    
