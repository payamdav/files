from unittest import result
import numpy as np
import pandas as pd
from numba_trader.trader import Trader, enum
from itertools import product, chain
from types import SimpleNamespace
import time
import math
import multiprocessing as mp


class ProgressBar:
    def __init__(self, total=0, current=0, new_line=False, default_steps=1):
        self.total = total
        self.current = current
        self.new_line = new_line
        self.default_steps = default_steps
        self.start_time = time.time()
        self.rounded_progress = 0
    
    def update(self, current=None, steps=None):
        self.current = self.current + self.default_steps if steps is None else self.current + steps
        self.current = self.current if current is None else current
        rounded_progress = 100 * self.current // self.total if self.total > 0 else 0
        if self.rounded_progress != rounded_progress:
            laps = round(time.time() - self.start_time, 2)
            if self.new_line:
                print(f"Progress: {rounded_progress}% - Duration: {laps}")
            else:
                print(f"\rProgress: {rounded_progress}% - Duration: {laps}", end='')
        self.rounded_progress = rounded_progress


class BackTester:
    def __init__(self, candles, price='Close', tp=0, sl=0, rrr=0, fee=0, max_interval=0, freq='H', direction=1, quote_amount=10, exit_order_on_interval=0, exit_on_same_candle=0, max_orders=10000000, max_open_orders=10000000, slots=1, process_count=1, non_product=[], **kw):
        self.tp = tp
        self.sl = sl
        self.rrr = rrr
        self.fee = fee
        self.max_interval = max_interval
        self.freq = freq
        self.direction = direction
        self.quote_amount = quote_amount
        self.exit_order_on_interval = exit_order_on_interval
        self.exit_on_same_candle = exit_on_same_candle
        self.max_orders = max_orders
        self.max_open_orders = max_open_orders
        if isinstance(candles, pd.DataFrame):
            self.candles = candles
        else:
            print("Please Provide candles in Pandas Dataframe format")
        self.ncandles = self.candles[['Open', 'High', 'Low', 'Close', 'a']].to_numpy()
        self.price = price
        self.slots = slots
        self.period = self.candles.shape[0] // slots

        self.kw = kw
        self.non_product = non_product
        self.signal_product = self.signal_parameters_product()
        self.trade_product = self.trade_parameters_product()
        
        self.process_count = process_count if process_count > 0 else mp.cpu_count()
        self.progress = None
    
    def trade_parameters_product(self):
        if pd.api.types.is_list_like(self.rrr) and pd.api.types.is_list_like(self.sl):
            trade_product = [dict(zip(('tp', 'sl'), (val[0]*val[1], val[1]))) for val in product(self.rrr, self.sl)]
        elif pd.api.types.is_list_like(self.rrr) and pd.api.types.is_list_like(self.tp):
            trade_product = [dict(zip(('tp', 'sl'), (val[1], val[1] / val[0]))) for val in product(self.rrr, self.tp)]
        elif pd.api.types.is_list_like(self.sl) and pd.api.types.is_list_like(self.tp):
            trade_product = [dict(zip(('tp', 'sl'), val)) for val in product(self.tp, self.sl)]
        else:
            trade_product = [{'tp': self.tp, 'sl': self.sl}]
        [trade_product[i].update({'trade_idx': f'T{i}'}) for i in range(len(trade_product))]
        return trade_product
    
    def signal_parameters_product(self):
        product_args = []
        non_product_args = []
        for a in self.kw:
            if a not in self.non_product and pd.api.types.is_list_like(self.kw[a]):
                product_args.append(a)
            else:
                non_product_args.append(a)
        signal_product = [dict(chain(zip(product_args, val), zip(non_product_args, [self.kw[npval] for npval in non_product_args]))) for val in product(*[self.kw[k] for k in product_args])]
        [signal_product[i].update({'sig_idx': f'S{i}'}) for i in range(len(signal_product))]
        return signal_product

    def signal_long_entry(self, p):
        return []
    
    def signal_long_exit(self, p):
        return []
    
    def signal_long(self, p):
        return self.signal_long_entry(p), self.signal_long_exit(p)

    def signal_short_entry(self, p):
        return []
    
    def signal_short_exit(self, p):
        return []

    def signal_short(self, p):
        return self.signal_short_entry(p), self.signal_short_exit(p)

    def run_single_process(self):
        results = []
        for signal_parameters in self.signal_product:
            results.extend(self.signal_parameters_loop(signal_parameters))
            self.progress.update()
        return results
    
    def signal_parameters_loop(self, signal_parameters):
        results = []
        if self.direction in [enum.long, enum.both]:
            dir = enum.long
            entry, exit = self.signal_long(SimpleNamespace(**signal_parameters))
            for trade_parameters in self.trade_product:
                for slot in range(0, self.slots):
                    idx = f"{signal_parameters['sig_idx']}{trade_parameters['trade_idx']}"
                    parameters = {**signal_parameters, **trade_parameters, **{'idx': idx, 'dir': dir, 'slot': slot}}
                    del parameters['sig_idx']
                    del parameters['trade_idx']
                    t = Trader(candles=self.candles.iloc[slot * self.period:(slot+2) * self.period], signal_entries=entry[slot * self.period: (slot+1) * self.period], signal_exits=exit[slot * self.period:], price=self.price, tp=parameters['tp'], sl=parameters['tp'], fee=self.fee, max_interval=self.max_interval, freq=self.freq, exit_order_on_interval=self.exit_order_on_interval, exit_on_same_candle=self.exit_on_same_candle, quote_amount=self.quote_amount, direction=dir, max_orders=min(self.max_orders, self.period), max_open_orders=self.max_open_orders,)
                    t.trade_runner()
                    results.append({**parameters, **t.report()._asdict()})
        if self.direction in [enum.short, enum.both]:
            dir = enum.short
            entry, exit = self.signal_short(SimpleNamespace(**signal_parameters))
            for trade_parameters in self.trade_product:
                for slot in range(0, self.slots):
                    idx = f"{signal_parameters['sig_idx']}{trade_parameters['trade_idx']}"
                    parameters = {**signal_parameters, **trade_parameters, **{'idx': idx, 'dir': dir, 'slot': slot}}
                    del parameters['sig_idx']
                    del parameters['trade_idx']
                    t = Trader(candles=self.candles.iloc[slot * self.period:(slot+2) * self.period], signal_entries=entry[slot * self.period: (slot+1) * self.period], signal_exits=exit[slot * self.period:], price=self.price, tp=parameters['tp'], sl=parameters['tp'], fee=self.fee, max_interval=self.max_interval, freq=self.freq, exit_order_on_interval=self.exit_order_on_interval, exit_on_same_candle=self.exit_on_same_candle, quote_amount=self.quote_amount, direction=dir, max_orders=min(self.max_orders, self.period), max_open_orders=self.max_open_orders,)
                    t.trade_runner()
                    results.append({**parameters, **t.report()._asdict()})
        return results
    
    def chunker(self, chunk_index):
        n = math.ceil(len(self.signal_product) / self.process_count)
        return self.signal_product[n*chunk_index:(chunk_index + 1) * n]
    
    def chunk_runner(self, chunk, pid, q):
        for signal_parameters in chunk:
            results = self.signal_parameters_loop(signal_parameters)
            q.put({'type': 'signal_parameters_loop_result', 'pid': pid, 'results': results})
        q.put({'type': 'finish', 'pid': pid})

    def run_multi_process(self):
        results = []

        q = mp.Queue()
        processes = {}
        for pid in range(self.process_count):
            p = mp.Process(target=self.chunk_runner, args=(self.chunker(pid), pid, q,))
            processes[pid] = p
        [p.start() for p in processes.values()]
        
        while len(processes.keys()) > 0:
            while q.empty() == False:
                m = q.get()
                if m['type'] == 'signal_parameters_loop_result':
                    results.extend(m['results'])
                    self.progress.update()
                elif m['type'] == 'finish':
                    del processes[m['pid']]
            time.sleep(0.5)
        return results
    
    def run(self):
        self.pre_report()
        self.progress = ProgressBar(total=len(self.trade_product) * len(self.signal_product) * (2 if self.direction == enum.both else 1 ) * self.slots, default_steps=len(self.trade_product) * (2 if self.direction == enum.both else 1 ) * self.slots)
        if self.process_count == 1:
            results = self.run_single_process()
        else:
            results = self.run_multi_process()
        print(f"\r\nResults ready. Len Results -> {len(results)}")
        return pd.DataFrame(data=results, index=range(len(results)))

    def pre_report(self):
        print(f"Number of Candles: {len(self.candles)}")
        print(f"Number of Slots: {self.slots} (Period: {self.period})")
        print(f"Number of Signal Parameters: {len(self.signal_product)}")
        print(f"Number of Trade Parameters: {len(self.trade_product)}")
        print(f"Directions (Long/Short): {(2 if self.direction == enum.both else 1 )}")
        print(f"Number of Iteration: {len(self.trade_product) * len(self.signal_product) * (2 if self.direction == enum.both else 1 ) * self.slots}")
        print(f"Number of Processes: {self.process_count}")
        print("-" * 100)
