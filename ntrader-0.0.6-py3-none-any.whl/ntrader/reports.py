import pandas as pd


columns_list = ['cash', 'min_cash', 'max_cash', 'order_count', 'long_count', 'short_count', 'totalprofit', 'fees', 'duration', 'min_duration', 'max_duration', 'min_profit', 'max_profit', 'positive_profit', 'negative_profit', 'long_profit', 'short_profit', 'win_trades', 'loss_trades', 'ex_tp', 'ex_sl', 'ex_interval', 'ex_open', 'ex_signal', 'return_p', 'avg_duration', 'avg_profit', 'win_rate']


def slot_report(sparams, col=0):
    sdf = pd.DataFrame(data=sparams[col, :, :], index=range(sparams.shape[1]), columns=columns_list)
    return sdf


def report(params):
    df = pd.DataFrame(data=params, index=range(params.shape[0]), columns=columns_list)
    return df
