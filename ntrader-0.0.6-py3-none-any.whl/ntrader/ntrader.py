import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import numpy as np
import numba as nb
import collections


Enum = collections.namedtuple('Enum', [
    'open',
    'high',
    'low',
    'close',

    'false',
    'true',

    'long',
    'short',
    'both',

    'id',
    'status',
    'direction',
    'size',
    'quote',
    'entry',
    'exit',
    'bprice',
    'sprice',
    'tp',
    'sl',
    'bfee',
    'sfee',
    'profit',
    'slot',

    'unused',
    'inposition',
    'exited',
    'exit_tp',
    'exit_sl',
    'exit_interval',
    'exit_signal',
    'exit_open',

    'cash',
    'min_cash',
    'max_cash',
    'order_count',
    'long_count',
    'short_count',
    'totalprofit',
    'fees',
    'duration',
    'min_duration',
    'max_duration',
    'min_profit',
    'max_profit',
    'positive_profit',
    'negative_profit',
    'long_profit',
    'short_profit',
    'win_trades',
    'loss_trades',
    'ex_tp',
    'ex_sl',
    'ex_interval',
    'ex_open',
    'ex_signal',
    'return_p',
    'avg_duration',
    'avg_profit',
    'win_rate',
    'sltp',
    'sl_val',
    'tp_val',
    'slot_val',
    'tag_start'

    ])

enum = Enum(0, 1, 2, 3, 0, 1, 1, 2, 3, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 1, 2, 3, 4, 5, 6, 7, 8, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32)


@nb.jit(nopython=True, parallel=False, nogil=True, cache=True)
def nb_trader(ncandles, nentries, nexits, nsentries, nsexits, tp, sl, fee, max_interval, norders, nprice, quote_amount, exit_order_on_interval, exit_on_same_candle, params, sparams, slots, period, cols, max_orders, max_open_orders):
    # rows_number = ncandles.shape[0]
    rows_number = slots * period
    order_ids = []
    open_orders = []
    for c in range(cols):
        open_orders.append(0)
    
    params[:, enum.min_cash] = np.inf
    params[:, enum.max_cash] = -np.inf
    params[:, enum.min_duration] = np.inf
    params[:, enum.max_duration] = -np.inf
    params[:, enum.min_profit] = np.inf
    params[:, enum.max_profit] = -np.inf
    sparams[:, :, enum.min_cash] = np.inf
    sparams[:, :, enum.min_profit] = np.inf
    sparams[:, :, enum.min_duration] = np.inf
    sparams[:, :, enum.max_cash] = -np.inf
    sparams[:, :, enum.max_profit] = -np.inf
    sparams[:, :, enum.max_duration] = -np.inf

    for i in range(0, rows_number):
        
        for c in range(cols):
            slot = int(i // period)
            if nentries[i] == 1 and open_orders[c] < max_open_orders and params[c, enum.order_count] < max_orders:
                buy_price = nprice[i]
                norders[int(params[c, enum.order_count]), c, enum.id] = int(params[c, enum.order_count])
                norders[int(params[c, enum.order_count]), c, enum.status] = enum.inposition
                norders[int(params[c, enum.order_count]), c, enum.direction] = enum.long
                norders[int(params[c, enum.order_count]), c, enum.size] = quote_amount / buy_price
                norders[int(params[c, enum.order_count]), c, enum.quote] = quote_amount
                norders[int(params[c, enum.order_count]), c, enum.entry] = i
                norders[int(params[c, enum.order_count]), c, enum.exit] = 0
                norders[int(params[c, enum.order_count]), c, enum.bprice] = buy_price
                norders[int(params[c, enum.order_count]), c, enum.sprice] = 0.0
                if norders[int(params[c, enum.order_count]), c, enum.direction] == enum.long:
                    norders[int(params[c, enum.order_count]), c, enum.tp] = buy_price * (1.0 + tp[c]) if tp[c] > 0 else 0
                    norders[int(params[c, enum.order_count]), c, enum.sl] = buy_price * (1.0 - sl[c]) if sl[c] > 0 else 0
                else:
                    norders[int(params[c, enum.order_count]), c, enum.tp] = buy_price * (1.0 - tp[c]) if tp[c] > 0 else 0
                    norders[int(params[c, enum.order_count]), c, enum.sl] = buy_price * (1.0 + sl[c]) if sl[c] > 0 else 0
                norders[int(params[c, enum.order_count]), c, enum.bfee] = quote_amount * fee
                norders[int(params[c, enum.order_count]), c, enum.sfee] = 0.0
                norders[int(params[c, enum.order_count]), c, enum.profit] = 0.0
                norders[int(params[c, enum.order_count]), c, enum.slot] = slot

                order_ids.append((int(params[c, enum.order_count]), c))
                params[c, enum.order_count] += 1
                sparams[c, slot, enum.order_count] += 1
                open_orders[c] += 1

                params[c, enum.cash] -= quote_amount
                if params[c, enum.cash] < params[c, enum.min_cash]:
                    params[c, enum.min_cash] = params[c, enum.cash]
                if params[c, enum.cash] > params[c, enum.max_cash]:
                    params[c, enum.max_cash] = params[c, enum.cash]

                sparams[c, slot, enum.cash] -= quote_amount
                if sparams[c, slot, enum.cash] < sparams[c, slot, enum.min_cash]:
                    sparams[c, slot, enum.min_cash] = sparams[c, slot, enum.cash]
                if sparams[c, slot, enum.cash] > sparams[c, slot, enum.max_cash]:
                    sparams[c, slot, enum.max_cash] = sparams[c, slot, enum.cash]

            if nsentries[i] == 1 and open_orders[c] < max_open_orders and params[c, enum.order_count] < max_orders:
                buy_price = nprice[i]
                norders[int(params[c, enum.order_count]), c, enum.id] = int(params[c, enum.order_count])
                norders[int(params[c, enum.order_count]), c, enum.status] = enum.inposition
                norders[int(params[c, enum.order_count]), c, enum.direction] = enum.short
                norders[int(params[c, enum.order_count]), c, enum.size] = quote_amount / buy_price
                norders[int(params[c, enum.order_count]), c, enum.quote] = quote_amount
                norders[int(params[c, enum.order_count]), c, enum.entry] = i
                norders[int(params[c, enum.order_count]), c, enum.exit] = 0
                norders[int(params[c, enum.order_count]), c, enum.bprice] = buy_price
                norders[int(params[c, enum.order_count]), c, enum.sprice] = 0.0
                if norders[int(params[c, enum.order_count]), c, enum.direction] == enum.long:
                    norders[int(params[c, enum.order_count]), c, enum.tp] = buy_price * (1.0 + tp[c]) if tp[c] > 0 else 0
                    norders[int(params[c, enum.order_count]), c, enum.sl] = buy_price * (1.0 - sl[c]) if sl[c] > 0 else 0
                else:
                    norders[int(params[c, enum.order_count]), c, enum.tp] = buy_price * (1.0 - tp[c]) if tp[c] > 0 else 0
                    norders[int(params[c, enum.order_count]), c, enum.sl] = buy_price * (1.0 + sl[c]) if sl[c] > 0 else 0
                norders[int(params[c, enum.order_count]), c, enum.bfee] = quote_amount * fee
                norders[int(params[c, enum.order_count]), c, enum.sfee] = 0.0
                norders[int(params[c, enum.order_count]), c, enum.profit] = 0.0
                norders[int(params[c, enum.order_count]), c, enum.slot] = slot

                order_ids.append((int(params[c, enum.order_count]), c))
                params[c, enum.order_count] += 1
                sparams[c, slot, enum.order_count] += 1
                open_orders[c] += 1

                params[c, enum.cash] -= quote_amount
                if params[c, enum.cash] < params[c, enum.min_cash]:
                    params[c, enum.min_cash] = params[c, enum.cash]
                if params[c, enum.cash] > params[c, enum.max_cash]:
                    params[c, enum.max_cash] = params[c, enum.cash]

                sparams[c, slot, enum.cash] -= quote_amount
                if sparams[c, slot, enum.cash] < sparams[c, slot, enum.min_cash]:
                    sparams[c, slot, enum.min_cash] = sparams[c, slot, enum.cash]
                if sparams[c, slot, enum.cash] > sparams[c, slot, enum.max_cash]:
                    sparams[c, slot, enum.max_cash] = sparams[c, slot, enum.cash]

        for j, c in order_ids.copy():

            if norders[j, c, enum.status] == enum.inposition and (exit_on_same_candle == enum.true or norders[j, c, enum.entry] < i):
                slot = int(norders[j, c, enum.entry] // period)
                sell_price = 0
                if exit_order_on_interval == 1 and (i - norders[j, c, enum.entry] > max_interval > 0):
                    # sell_price = ncandles[i, enum.open]
                    sell_price = nprice[i]
                    norders[j, c, enum.status] = enum.exit_interval
                    params[c, enum.ex_interval] += 1
                    sparams[c, slot, enum.ex_interval] += 1
                elif norders[j, c, enum.sl] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.open] <= norders[j, c, enum.sl]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.open] >= norders[j, c, enum.sl])):
                    sell_price = norders[j, c, enum.sl]
                    norders[j, c, enum.status] = enum.exit_sl
                    params[c, enum.ex_sl] += 1
                    sparams[c, slot, enum.ex_sl] += 1
                elif norders[j, c, enum.tp] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.open] >= norders[j, c, enum.tp]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.open] <= norders[j, c, enum.tp])):
                    sell_price = norders[j, c, enum.tp]
                    norders[j, c, enum.status] = enum.exit_tp
                    params[c, enum.ex_tp] += 1
                    sparams[c, slot, enum.ex_tp] += 1
                elif norders[j, c, enum.sl] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.low] <= norders[j, c, enum.sl]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.high] >= norders[j, c, enum.sl])):
                    sell_price = norders[j, c, enum.sl]
                    norders[j, c, enum.status] = enum.exit_sl
                    params[c, enum.ex_sl] += 1
                    sparams[c, slot, enum.ex_sl] += 1
                elif norders[j, c, enum.tp] > 0 and ((norders[j, c, enum.direction] == enum.long and ncandles[i, enum.high] >= norders[j, c, enum.tp]) or (norders[j, c, enum.direction] == enum.short and ncandles[i, enum.low] <= norders[j, c, enum.tp])):
                    sell_price = norders[j, c, enum.tp]
                    norders[j, c, enum.status] = enum.exit_tp
                    params[c, enum.ex_tp] += 1
                    sparams[c, slot, enum.ex_tp] += 1
                elif (nexits[i] == 1 and norders[j, c, enum.direction] == enum.long) or (nsexits[i] == 1 and norders[j, c, enum.direction] == enum.short):
                    # sell_price = ncandles[i, enum.open]
                    sell_price = nprice[i]
                    norders[j, c, enum.status] = enum.exit_signal
                    params[c, enum.ex_signal] += 1
                    sparams[c, slot, enum.ex_signal] += 1
                
                if sell_price > 0:
                    sell_quote = sell_price * norders[j, c, enum.size]
                    norders[j, c, enum.exit] = i
                    norders[j, c, enum.sprice] = sell_price
                    norders[j, c, enum.sfee] = sell_quote * fee
                    profit = (sell_quote - norders[j, c, enum.quote] - norders[j, c, enum.bfee] - norders[j, c, enum.sfee]) if norders[j, c, enum.direction] == enum.long else (norders[j, c, enum.quote] - sell_quote - norders[j, c, enum.bfee] - norders[j, c, enum.sfee])
                    norders[j, c, enum.profit] = profit

                    order_ids.remove((norders[j, c, enum.id], c))
                    open_orders[c] -= 1

                    params[c, enum.cash] += (norders[j, c, enum.quote] + norders[j, c, enum.profit])
                    if params[c, enum.cash] < params[c, enum.min_cash]:
                        params[c, enum.min_cash] = params[c, enum.cash]
                    if params[c, enum.cash] > params[c, enum.max_cash]:
                        params[c, enum.max_cash] = params[c, enum.cash]

                    sparams[c, slot, enum.cash] += (norders[j, c, enum.quote] + profit)
                    if sparams[c, slot, enum.cash] < sparams[c, slot, enum.min_cash]:
                        sparams[c, slot, enum.min_cash] = sparams[c, slot, enum.cash]
                    if sparams[c, slot, enum.cash] > sparams[c, slot, enum.max_cash]:
                        sparams[c, slot, enum.max_cash] = sparams[c, slot, enum.cash]
                    params[c, enum.totalprofit] += profit
                    sparams[c, slot, enum.totalprofit] += profit
                    params[c, enum.fees] += (norders[j, c, enum.bfee] + norders[j, c, enum.sfee])
                    sparams[c, slot, enum.fees] += (norders[j, c, enum.bfee] + norders[j, c, enum.sfee])
                    duration = norders[j, c, enum.exit] - norders[j, c, enum.entry]
                    params[c, enum.duration] += duration
                    sparams[c, slot, enum.duration] += duration
                    if duration < params[c, enum.min_duration]:
                        params[c, enum.min_duration] = duration
                    if duration > params[c, enum.max_duration]:
                        params[c, enum.max_duration] = duration
                    if duration < sparams[c, slot, enum.min_duration]:
                        sparams[c, slot, enum.min_duration] = duration
                    if duration > sparams[c, slot, enum.max_duration]:
                        sparams[c, slot, enum.max_duration] = duration
                    if profit >= 0:
                        params[c, enum.positive_profit] += profit
                        sparams[c, slot, enum.positive_profit] += profit
                        params[c, enum.win_trades] += 1
                        sparams[c, slot, enum.win_trades] += 1
                    else:
                        params[c, enum.negative_profit] += profit
                        sparams[c, slot, enum.negative_profit] += profit
                        params[c, enum.loss_trades] += 1
                        sparams[c, slot, enum.loss_trades] += 1
                    if profit < params[c, enum.min_profit]:
                        params[c, enum.min_profit] = profit
                    if profit > params[c, enum.max_profit]:
                        params[c, enum.max_profit] = profit
                    if profit < sparams[c, slot, enum.min_profit]:
                        sparams[c, slot, enum.min_profit] = profit
                    if profit > sparams[c, slot, enum.max_profit]:
                        sparams[c, slot, enum.max_profit] = profit
                    if norders[j, c, enum.direction] == enum.long:
                        params[c, enum.long_count] += 1
                        sparams[c, slot, enum.long_count] += 1
                        params[c, enum.long_profit] += profit
                        sparams[c, slot, enum.long_profit] += profit
                    elif norders[j, c, enum.direction] == enum.short:
                        params[c, enum.short_count] += 1
                        sparams[c, slot, enum.short_count] += 1
                        params[c, enum.short_profit] += profit
                        sparams[c, slot, enum.short_profit] += profit
                    
    sell_price = ncandles[-1, enum.close]
    for j, c in order_ids.copy():
        if norders[j, c, enum.status] == enum.inposition:
            slot = int(norders[j, c, enum.entry] // period)
            norders[j, c, enum.status] = enum.exit_open
            params[c, enum.ex_open] += 1
            sparams[c, slot, enum.ex_open] += 1
            sell_quote = sell_price * norders[j, c, enum.size]
            norders[j, c, enum.exit] = rows_number - 1
            norders[j, c, enum.sprice] = sell_price
            norders[j, c, enum.sfee] = sell_quote * fee
            profit = (sell_quote - norders[j, c, enum.quote] - norders[j, c, enum.bfee] - norders[j, c, enum.sfee]) if norders[j, c, enum.direction] == enum.long else (norders[j, c, enum.quote] - sell_quote - norders[j, c, enum.bfee] - norders[j, c, enum.sfee])
            norders[j, c, enum.profit] = profit

            order_ids.remove((norders[j, c, enum.id], c))
            open_orders[c] -= 1

            params[c, enum.cash] += (norders[j, c, enum.quote] + norders[j, c, enum.profit])
            if params[c, enum.cash] < params[c, enum.min_cash]:
                params[c, enum.min_cash] = params[c, enum.cash]
            if params[c, enum.cash] > params[c, enum.max_cash]:
                params[c, enum.max_cash] = params[c, enum.cash]

            sparams[c, slot, enum.cash] += (norders[j, c, enum.quote] + profit)
            if sparams[c, slot, enum.cash] < sparams[c, slot, enum.min_cash]:
                sparams[c, slot, enum.min_cash] = sparams[c, slot, enum.cash]
            if sparams[c, slot, enum.cash] > sparams[c, slot, enum.max_cash]:
                sparams[c, slot, enum.max_cash] = sparams[c, slot, enum.cash]
            params[c, enum.totalprofit] += profit
            sparams[c, slot, enum.totalprofit] += profit
            params[c, enum.fees] += (norders[j, c, enum.bfee] + norders[j, c, enum.sfee])
            sparams[c, slot, enum.fees] += (norders[j, c, enum.bfee] + norders[j, c, enum.sfee])
            duration = norders[j, c, enum.exit] - norders[j, c, enum.entry]
            params[c, enum.duration] += duration
            sparams[c, slot, enum.duration] += duration
            if duration < params[c, enum.min_duration]:
                params[c, enum.min_duration] = duration
            if duration > params[c, enum.max_duration]:
                params[c, enum.max_duration] = duration
            if duration < sparams[c, slot, enum.min_duration]:
                sparams[c, slot, enum.min_duration] = duration
            if duration > sparams[c, slot, enum.max_duration]:
                sparams[c, slot, enum.max_duration] = duration
            if profit >= 0:
                params[c, enum.positive_profit] += profit
                sparams[c, slot, enum.positive_profit] += profit
                params[c, enum.win_trades] += 1
                sparams[c, slot, enum.win_trades] += 1
            else:
                params[c, enum.negative_profit] += profit
                sparams[c, slot, enum.negative_profit] += profit
                params[c, enum.loss_trades] += 1
                sparams[c, slot, enum.loss_trades] += 1
            if profit < params[c, enum.min_profit]:
                params[c, enum.min_profit] = profit
            if profit > params[c, enum.max_profit]:
                params[c, enum.max_profit] = profit
            if profit < sparams[c, slot, enum.min_profit]:
                sparams[c, slot, enum.min_profit] = profit
            if profit > sparams[c, slot, enum.max_profit]:
                sparams[c, slot, enum.max_profit] = profit
            if norders[j, c, enum.direction] == enum.long:
                params[c, enum.long_count] += 1
                sparams[c, slot, enum.long_count] += 1
                params[c, enum.long_profit] += profit
                sparams[c, slot, enum.long_profit] += profit
            elif norders[j, c, enum.direction] == enum.short:
                params[c, enum.short_count] += 1
                sparams[c, slot, enum.short_count] += 1
                params[c, enum.short_profit] += profit
                sparams[c, slot, enum.short_profit] += profit
    params[:, enum.avg_duration] = params[:, enum.duration] / params[:, enum.order_count]
    params[:, enum.avg_profit] = params[:, enum.totalprofit] / params[:, enum.order_count]
    params[:, enum.win_rate] = 100 * params[:, enum.win_trades] / params[:, enum.order_count]
    params[:, enum.return_p] = -100 * params[:, enum.totalprofit] / params[:, enum.min_cash]
    sparams[:, :, enum.avg_duration] = sparams[:, :, enum.duration] / sparams[:, :, enum.order_count]
    sparams[:, :, enum.avg_profit] = sparams[:, :, enum.totalprofit] / sparams[:, :, enum.order_count]
    sparams[:, :, enum.win_rate] = 100 * sparams[:, :, enum.win_trades] / sparams[:, :, enum.order_count]
    sparams[:, :, enum.return_p] = -100 * sparams[:, :, enum.totalprofit] / sparams[:, :, enum.min_cash]


def ntrader(ncandles, nentries=np.array([0]), nexits=np.array([0]), nsentries=np.array([0]), nsexits=np.array([0]), nprice=None, tp=np.array([0]), sl=np.array([0]), fee=0., max_interval=0, slots=1, quote_amount=10, exit_order_on_interval=0, exit_on_same_candle=0, max_orders=10000000, max_open_orders=10000000, tags=[]):
    nprice = ncandles[:, enum.close] if nprice is None else nprice
    rows = ncandles.shape[0]
    nentries = nentries.copy()
    nexits = nexits.copy()
    nsentries = nsentries.copy()
    nsexits = nsexits.copy()
    nentries.resize(rows)
    nexits.resize(rows)
    nsentries.resize(rows)
    nsexits.resize(rows)
    tmp = max(sl.shape[0], tp.shape[0])
    sl = np.resize(sl, tmp)
    tp = np.resize(tp, tmp)
    cols = sl.shape[0]
    period = rows // slots

    norders = np.full((min(rows * 2, max_orders), cols, 15), 0.)
    params = np.full((cols, 32 + len(tags)), 0.)
    sparams = np.full((cols, slots, 32 + len(tags)), 0.)

    params[:, enum.sl_val] = sl
    params[:, enum.tp_val] = tp
    params[:, enum.sltp] = range(sl.shape[0])
    sparams[:, :, enum.sl_val] = np.repeat(sl, sparams.shape[1]).reshape(sparams.shape[0], sparams.shape[1])
    sparams[:, :, enum.tp_val] = np.repeat(tp, sparams.shape[1]).reshape(sparams.shape[0], sparams.shape[1])
    sparams[:, :, enum.sltp] = np.repeat(range(sl.shape[0]), sparams.shape[1]).reshape(sparams.shape[0], sparams.shape[1])
    sparams[:, :, enum.slot_val] = np.tile(range(slots), sparams.shape[0]).reshape(sparams.shape[0], sparams.shape[1])
    if len(tags) > 0:
        sparams[:, :, enum.tag_start:] = tags
        params[:, enum.tag_start:] = tags
    nb_trader(ncandles, nentries, nexits, nsentries, nsexits, tp, sl, fee, max_interval, norders, nprice, quote_amount, exit_order_on_interval, exit_on_same_candle, params, sparams, slots, period, cols, max_orders, max_open_orders)
    return params, sparams, norders
