import numpy as np
import pandas as pd
from itertools import product
from types import SimpleNamespace
import time
import math
from ntrader.ntrader import ntrader, enum
import multiprocessing as mp


class ProgressBar:
    def __init__(self, total=0, current=0, new_line=False, default_steps=1):
        self.total = total
        self.current = current
        self.new_line = new_line
        self.default_steps = default_steps
        self.start_time = time.time()
        self.rounded_progress = 0
    
    def update(self, current=None, steps=None):
        self.current = self.current + self.default_steps if steps is None else self.current + steps
        self.current = self.current if current is None else current
        rounded_progress = 100 * self.current // self.total if self.total > 0 else 0
        if self.rounded_progress != rounded_progress:
            laps = round(time.time() - self.start_time, 2)
            if self.new_line:
                print(f"Progress: {rounded_progress}% - Duration: {laps}")
            else:
                print(f"\rProgress: {rounded_progress}% - Duration: {laps}", end='')
        self.rounded_progress = rounded_progress


class BackTester:
    def __init__(self, candles, price='Close', tp=0, sl=0, rrr=None, fee=0, max_interval=0, quote_amount=10, exit_order_on_interval=0, exit_on_same_candle=0, max_orders=10000000, max_open_orders=10000000, slots=1, process_count=1, non_product=[], **kw):
        self.tp = np.array(tp).copy() if len(np.array(tp).shape) == 1 else np.array(tp)[None].copy()
        self.sl = np.array(sl).copy() if len(np.array(sl).shape) == 1 else np.array(sl)[None].copy()
        self.rrr = None if rrr is None else np.array(rrr).copy() if len(np.array(rrr).shape) == 1 else np.array(rrr)[None].copy()
        self.tp, self.sl, self.sltp_count = self.trade_parameters()
        self.fee = fee
        self.max_interval = max_interval
        self.quote_amount = quote_amount
        self.exit_order_on_interval = exit_order_on_interval
        self.exit_on_same_candle = exit_on_same_candle
        self.max_orders = max_orders
        self.max_open_orders = max_open_orders
        if isinstance(candles, pd.DataFrame):
            self.ncandles = candles[['Open', 'High', 'Low', 'Close', 'a']].to_numpy()
        else:
            print("Please Provide candles in Pandas Dataframe format")
        if isinstance(price, str) and price in candles.columns:
            self.nprice = candles[price].to_numpy()
        elif isinstance(price, pd.Series):
            self.nprice = price.to_numpy()
        else:
            self.nprice = self.ncandles[enum.close]
        self.slots = slots
        self.period = self.ncandles.shape[0] // slots

        self.kw = kw
        self.product_args = [k for k in kw if k not in non_product and pd.api.types.is_list_like(kw[k]) ]
        self.product_args_values = [kw[k] for k in self.product_args]
        self.non_product_args = [k for k in kw if k not in self.product_args]
        self.non_product_args_values = [kw[k] for k in self.non_product_args]
        self.signal_product_args_length = math.prod([len(item) for item in self.product_args_values])
        self.columns = tuple(['signal_id'] + self.product_args + self.non_product_args)
        
        self.process_count = process_count if process_count > 0 else mp.cpu_count()
        self.progress = None

        self.pre_report()
    
    def trade_parameters(self):
        if self.rrr is not None:
            p = list(zip(*[(val[0]*val[1], val[1]) for val in product(self.rrr, self.sl)]))
            return np.array(p[0]), np.array(p[1]), len(p[0])
        else:
            len_max = max(len(self.sl), len(self.tp))
            self.sl.resize(len_max)
            self.tp.resize(len_max)
            return self.tp, self.sl, len_max
    
    def sig_params(self):
        pools = [tuple(pool) for pool in self.product_args_values]
        result = [[]]
        for pool in pools:
            result = [x+[y] for x in result for y in pool]
        for index, prod in enumerate(result):
            yield (index,) + tuple(prod) + tuple(self.non_product_args_values)

    def sig_params_by_index(self, index):
        if index > self.signal_product_args_length:
            return None
        lens = [len(a) for a in self.product_args_values]
        gains = []
        g = 1
        last_item = 1
        for i in range(len(lens)-1, -1, -1):
            item = g * last_item
            g = item
            last_item = lens[i]
            gains.insert(0, item)
        r = [0] * len(self.product_args_values)
        n = index
        for i, g in enumerate(gains):
            r[i], n = divmod(n, g)
        return (index,) + tuple([self.product_args_values[i][j] for i, j in enumerate(r)]) + tuple(self.non_product_args_values)


    def signal_long_entry(self, p):
        return np.array([0])
    
    def signal_long_exit(self, p):
        return np.array([0])
    
    def signal_long(self, p):
        return self.signal_long_entry(p), self.signal_long_exit(p)

    def signal_short_entry(self, p):
        return np.array([0])
    
    def signal_short_exit(self, p):
        return np.array([0])

    def signal_short(self, p):
        return self.signal_short_entry(p), self.signal_short_exit(p)
    
    def signal(self, p):
        return self.signal_long(p) + self.signal_short(p)
    
    def result_filter(self, params, sparams):
        return params, sparams

    def plugin(self, params, sparams, norders):
        pass

    def run_single_process(self):
        results = []
        sresults = []
        for i in range(self.signal_product_args_length):
            params, sparams = self.signal_parameters_loop(self.sig_params_by_index(i))
            if params.shape[0] > 0:
                results.append(params)
            if sparams.shape[0] > 0:
                sresults.append(sparams)
            self.progress.update()
        return results, sresults
    
    def run_single_process2(self):
        results = []
        sresults = []
        for signal_parameters in self.sig_params():
            params, sparams = self.signal_parameters_loop(signal_parameters)
            if params.shape[0] > 0:
                results.append(params)
            if sparams.shape[0] > 0:
                sresults.append(sparams)
            self.progress.update()
        return results, sresults

    def signal_parameters_loop(self, signal_parameters):
        nentries, nexits, nsentries, nsexits = self.signal(SimpleNamespace(**dict(zip(self.columns, signal_parameters))))
        params, sparams, norders = ntrader(ncandles=self.ncandles, nentries=nentries, nexits=nexits, nsentries=nsentries, nsexits=nsexits, nprice=self.nprice, tp=self.tp, sl=self.sl, fee=self.fee, max_interval=self.max_interval, slots=self.slots, quote_amount=self.quote_amount, exit_order_on_interval=self.exit_order_on_interval, exit_on_same_candle=self.exit_on_same_candle, max_orders=self.max_orders, max_open_orders=self.max_open_orders, tags=signal_parameters)
        self.plugin(params, sparams, norders)
        fparams, fsparams = self.result_filter(params, sparams)
        return fparams.reshape(-1, params.shape[1]), fsparams.reshape(-1, sparams.shape[2])
    
    def chunk_runner(self, start_index, end_index, pid, q):
        start_time = time.time()
        print(f"pid:{pid} --> {start_index} -  {end_index}")
        for i in range(start_index, end_index):
            params, sparams = self.signal_parameters_loop(self.sig_params_by_index(i))
            q.put({'type': 'signal_parameters_loop_result', 'pid': pid, 'params': params, 'sparams': sparams})
        q.put({'type': 'finish', 'pid': pid})
        print(f"PID:{pid} - Bye - {time.time() - start_time}")

    def run_multi_process(self):
        results, sresults = [], []
        q = mp.Queue()
        processes = {}
        chunk_len = math.ceil(self.signal_product_args_length / self.process_count)
        for pid in range(self.process_count):
            start_index = pid * chunk_len
            end_index = min((pid + 1) * chunk_len, self.signal_product_args_length)
            processes[pid] = mp.Process(target=self.chunk_runner, args=(start_index, end_index, pid, q))
        [p.start() for p in processes.values()]
        
        while len(processes.keys()) > 0:
            while q.empty() == False:
                m = q.get()
                if m['type'] == 'signal_parameters_loop_result':
                    params, sparams = m['params'], m['sparams']
                    if params.shape[0] > 0:
                        results.append(params)
                    if sparams.shape[0] > 0:
                        sresults.append(sparams)
                    self.progress.update()
                elif m['type'] == 'finish':
                    del processes[m['pid']]
                    print(f"Process {m['pid']} - Finished")
            time.sleep(0.1)
        return results, sresults
    
    def run(self, pandas=False, save=False):
        start_time = time.time()
        self.progress = ProgressBar(total=self.sltp_count * self.signal_product_args_length * self.slots, default_steps=self.sltp_count * self.slots)
        if self.process_count == 1:
            results, sresults = self.run_single_process()
        else:
            results, sresults = self.run_multi_process()
        print(f"\r\nResults ready. Len Results -> {len(results)}  - Len SResults -> {len(sresults)}")
        print(f"Processing Time:{time.time() - start_time}")
        stack_time = time.time()
        np_results, np_sresults = np.vstack(results), np.vstack(sresults)
        print(f"Stacking Time:{time.time() - stack_time}")
        print(f"\r\nResults ready. Len Results -> {len(np_results)}  - Len SResults -> {len(np_sresults)}")
        if not pandas:
            return np_results, np_sresults
        else:
            pd_time = time.time()
            columns = enum._fields[-1 * enum[-1]-1:-1] + self.columns
            df_results, df_sresults = pd.DataFrame(data=np_results, columns=columns), pd.DataFrame(data=np_sresults, columns=columns)
            print(f"Pandas Time:{time.time() - pd_time}")
            return df_results, df_sresults

    def pre_report(self):
        print(f"Number of Candles: {self.ncandles.shape[0]}")
        print(f"Number of Slots: {self.slots} (Period: {self.period})")
        print(f"Number of Signal Parameters: {self.signal_product_args_length}")
        print(f"Number of Trade Parameters: {self.sltp_count}")
        print(f"Number of Iteration: {self.sltp_count * self.signal_product_args_length * self.slots}")
        print(f"Number of Processes: {self.process_count}")
        print("-" * 100)
