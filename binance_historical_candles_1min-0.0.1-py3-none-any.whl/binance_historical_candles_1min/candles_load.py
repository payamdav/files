from importlib.resources import path
import pandas as pd
import numpy as np
import os
import urllib.request
import shutil
import zipfile


# config
class ConfigClass:
    pass
config = ConfigClass()


if os.name == 'posix':
    path = '/var/temp/binance_historical_candles'
elif os.name == 'nt':
    path = 'c:\\temp\\binance_historical_candles'
else:
    print("unsupported OS!")
    exit()

if not os.path.exists(path=path):
    os.makedirs(path)
    print(f'storage directory created: {path}')
config.binance_historical_path = path


def year_month_iterator(year, month, to_year=0, to_month=0):
    to_year = year if to_year == 0 else to_year
    to_month = month if to_month == 0 else to_month
    for ym in range(12 * year + month - 1, 12 * to_year + to_month - 1 + 1):
        y, m = divmod(ym, 12)
        m += 1
        yield y, m


def pkl_filepath(symbol):
    return os.path.join(config.binance_historical_path, str(symbol).upper() + '_1min.pkl')


def download_binance_historical_candles_single(symbol, timeframe, year, month):
    try:
        symbol = str(symbol).strip().upper()
        timeframe = str(timeframe).strip().lower()
        year = str(year).strip()
        month = str(month).strip().zfill(2)
        binance_base_url = "https://data.binance.vision/data/spot/monthly/klines"
        url = f"{binance_base_url}/{symbol}/{timeframe}/{symbol}-{timeframe}-{year}-{month}.zip"
        file_name = f"{symbol}-{timeframe}-{year}-{month}.zip"
        file_path = os.path.join(config.binance_historical_path, file_name)
        with urllib.request.urlopen(url) as response, open(file_path, 'wb') as out_file:
            shutil.copyfileobj(response, out_file)
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(config.binance_historical_path)
        os.remove(file_path)
    except Exception as e:
        print("Error", e)


def download_binance_historical_candles(symbol, timeframe, year, month, to_year=0, to_month=0):
    try:
        for y, m in year_month_iterator(year, month, to_year, to_month):
            download_binance_historical_candles_single(symbol, timeframe, y, m)
    except Exception as e:
        print("Error", e)


def get_pandas_df_binance_historical_candles_from_local(symbol, timeframe, year, month, to_year=0, to_month=0):
    try:
        binance_to_pandas_freq = {
            '1m': '1T', '3m': '3T', '5m': '5T', '15m': '15T', '30m': '30T', '1h': 'H', '2h': '2H', '4h': '4H', '6h': '6H', '8h': '8H', '12h': '12H', '1d': 'D', '3d': '3D', '1w': 'W', '1mo': 'M'
        }
        header_names = ['ts', 'Open', 'High', 'Low', 'Close', 'Volume', 'Close_Time', 'q', 'n', 'tbb', 'tbq', 'ignore']
        use_columns = ['ts', 'Open', 'High', 'Low', 'Close', 'Volume', 'q', 'n']
        symbol = str(symbol).strip().upper()
        timeframe = str(timeframe).strip().lower()
        all_candles = pd.DataFrame()
        for y, m in year_month_iterator(year, month, to_year, to_month):
            file_name = f"{symbol}-{timeframe}-{str(y).strip()}-{str(m).strip().zfill(2)}.csv"
            file_path = os.path.join(config.binance_historical_path, file_name)
            candles = pd.read_csv(file_path, names=header_names, usecols=use_columns)
            candles['a'] = candles['q'] / candles['Volume']
            candles["time"] = pd.to_datetime(candles["ts"], unit="ms")
            candles.set_index("time", drop=False, inplace=True)
            candles = candles.asfreq(binance_to_pandas_freq[timeframe])
            # all_candles = pd.concat([all_candles, candles])
            all_candles = candles.combine_first(all_candles)
        return all_candles

    except Exception as e:
        print("Error", e)


def create_binance_cumulative_pickle(symbol, timeframe, year, month, to_year=0, to_month=0):
    candles = get_pandas_df_binance_historical_candles_from_local(symbol, timeframe, year, month, to_year, to_month)
    candles = candles.drop(["time", "ts"], axis=1)
    candles.fillna(method="ffill", inplace=True)
    candles.replace(0, np.nan, inplace=True)
    candles.fillna(method="ffill", inplace=True)
    candles.to_pickle(pkl_filepath(symbol))


def load_prepare_data(symbol, year, month, to_year=0, to_month=0):
    download_binance_historical_candles(str(symbol).upper(), '1m', year, month, to_year, to_month)
    create_binance_cumulative_pickle(str(symbol).upper(), '1m', year, month, to_year, to_month)
    

def candles_load(freq="T", symbol="BTCUSDT"):
    if str(symbol).upper() == "BTCUSDT":
        candles = pd.read_pickle(pkl_filepath(symbol)) \
            .resample(freq, closed='left', label='left', origin='start') \
            .agg({'Open': 'first', 'High': 'max', 'Low': 'min', 'Close': 'last', 'Volume': 'sum', 'q': 'sum', 'n': 'sum'})

        candles.fillna(method="ffill", inplace=True)
        candles['a'] = candles['q'] / candles['Volume']
        candles.replace(0, np.nan, inplace=True)
        candles.fillna(method="ffill", inplace=True)
        return candles
